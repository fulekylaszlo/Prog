#include <stdio.h>

int main ()
 {
 // Emiatt a komment miatt nem fog működni.
 printf ("Hello World\n");
 return 0;
 }
