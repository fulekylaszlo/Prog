#include <stdio.h>

int main ()
 {
 for ( ; ; )
 {
 }
 return 0;
 }
 
