#include <stdio.h>

int main()
 {
 int a=1;
 int i=1;
 
 while(a>0)
  {
  a<<=1;
  i++;
  }
  
 printf("A szóhossz:%d\n",i);
 return 0;
}
 
