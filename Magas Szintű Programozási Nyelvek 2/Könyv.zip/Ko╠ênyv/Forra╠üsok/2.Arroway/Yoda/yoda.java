class error
{ 
public static void main(String args[])
	{
	Integer Yoda = null;	
	int hey = Yoda.intValue();
    	System.out.println(hey); 	
	}
} 
