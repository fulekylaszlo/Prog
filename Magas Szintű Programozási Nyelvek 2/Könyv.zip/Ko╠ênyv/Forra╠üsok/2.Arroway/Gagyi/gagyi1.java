class Gagyi1
	{
	public static void main (String[]args)
		{

		Integer x = -130;
		Integer t = -130;
		while (x <= t && x >= t && t != x);

		System.out.println (x);
		System.out.println (t);
		}

	}

