class Gagyi2
	{
	public static void main (String[]args)
		{

		Integer x = -100;
		Integer t = -100;
		while (x <= t && x >= t && t != x);

		System.out.println (x);
		System.out.println (t);
		}

	}


