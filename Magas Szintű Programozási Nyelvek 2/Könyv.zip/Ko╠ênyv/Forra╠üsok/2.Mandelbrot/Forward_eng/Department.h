#ifndef DEPARTMENT_H
#define DEPARTMENT_H

class Department {

private:
	std::vector<dolog> dologs;
	String _name;

public:
	void startEmployment();
};

#endif
