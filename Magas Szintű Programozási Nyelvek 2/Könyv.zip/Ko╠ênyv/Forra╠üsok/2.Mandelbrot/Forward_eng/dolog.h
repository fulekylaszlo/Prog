#ifndef DOLOG_H
#define DOLOG_H

class dolog {

private:
	String _dologID;
};

#endif
