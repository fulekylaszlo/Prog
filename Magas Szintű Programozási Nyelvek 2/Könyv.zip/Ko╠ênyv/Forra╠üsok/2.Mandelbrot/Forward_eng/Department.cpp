#include "Department.h"

void Department::startEmployment() {
	// TODO - implement Department::startEmployment
	throw "Not yet implemented";
}
