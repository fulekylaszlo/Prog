## Prog2 könyv 📚

### Csokrokkal való haladás:

- [x] Berners
- [x] Arroway
- [x] Liskov
- [x] Mandelbrot
- [x] Chomsky
- [] Stroustrup /2019.10.25
- [] Gödel /2019.11.1
- [] Vessző /2019.11.8
- [] Schwarzenegger /2019.11.15
- [] Calvin /2019.11.22

### Repó/könyv teljes letöltése:
```
git clone https://github.com/fulekylaszlo/DEIK
```

#### A könyv MacOS Mojave 10.14.4 majd később MacOS Catalina 10.15 verzión lett elkészítve.


*Fontos megjegyezni, hogy a repóban nem csak a "Prog2" tantárgyra szükséges fájlok és könyv van, megtalálhatóak itt még a "Bevprog" és a "Prog1" tárgyra szükséges fájlok.*
